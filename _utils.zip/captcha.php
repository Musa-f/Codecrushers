<?php
   /***************************************/
    /*** Captcha par bilou89 ***/
    /*** bilou89-4sang@hotmail.fr ***/
    /***************************************/
    session_start(); // Création de la session
    $largeur = 200; // Largeur de l'image
    $hauteur = 80; // Hauteur de l'image
    // Liste des polices utilisées aléatoirement, à placer dans le dossier police/
    $polices = array('../divers/fonts/arimo.ttf'); //, 'polices/tahomabd.ttf', 'polices/verdanab.ttf');
    $image = imagecreatetruecolor($largeur, $hauteur); // Création de l'image
    $fond = imagecolorallocate($image, mt_rand(0, 150), mt_rand(0, 150), mt_rand(0, 150)); // Couleur de fond
    imagefill($image, 0, 0, $fond); // Coloration du fond
    /**************************************/
    /***  Traçage des lignes/cercles sur le fond ***/
    /**************************************/
    // 3 lignes vertial
    for($i = 0; $i < 3; $i++)
    {
            $couleur_ligne = imagecolorallocate($image, mt_rand(0, 150), mt_rand(0, 150), mt_rand(0, 150)); // Couleur de la ligne
            imagesetthickness($image, mt_rand(1, 4)); // Changement de l'épaisseur de la ligne
            imageline($image, 0, mt_rand(0, $hauteur), $largeur, mt_rand(0, $hauteur), $couleur_ligne); // Traçage de la ligne
    }
    // 3 lignes horizontal
    for($i = 0; $i < 3; $i++)
    {
            $couleur_ligne = imagecolorallocate($image, mt_rand(0, 150), mt_rand(0, 150), mt_rand(0, 150)); // Couleur de la ligne
            imagesetthickness($image, mt_rand(1, 4)); // Changement de l'épaisseur de la ligne
            imageline($image, mt_rand(0, $largeur), 0, mt_rand(0, $largeur), $hauteur, $couleur_ligne); // Traçage de la ligne
    }
    // 3 cercles
    for($i = 0; $i < 3; $i++)
    {
            $couleur_ligne = imagecolorallocate($image, mt_rand(0, 150), mt_rand(0, 150), mt_rand(0, 150)); // Couleur du cercle
            imagesetthickness($image, mt_rand(1, 2)); // Changement de l'épaisseur du cercle
            imageellipse($image, mt_rand(10, 290), mt_rand(10, 40), mt_rand(5, 60), mt_rand(5, 60), $couleur_ligne); //  Traçage du cercle
    }
    imagesetthickness($image, 1); // Remise de l'épaisseur des lignes, cercles, ... à 1px
    /**************************************/
    /*** Traçage des caractères sur le fond ***/
    /**************************************/
    $couleur_lettres = imagecolorallocate($image, mt_rand(0, 150), mt_rand(0, 150), mt_rand(0, 150)); // Couleur des lettres de fond
    $nb_caracteres = 20; // Nombre de caractères citués au fond
    $lettres = 'abcdefghijklmnopqrstuvwxyz-+*/@$&éè'; // Caractères utilisés pour les lettres de fond
    $lettres_melange = strlen($lettres); // Mélange des caractèred
    $x = mt_rand(5, 295); // Définition aléatoire de la position de X
    $y = mt_rand(5, 55); // Définition aléatoire de la position de Y
    $i = 0;
    // Boucle pour déssiner les caractères de fond
    while($i < $nb_caracteres)
    {      
            $lettre_a_ajouter = $lettres[mt_rand(0, $lettres_melange - 1)]; // Selection de la lettre à ajouter
            $taille = mt_rand(12, 20); // Définition de la taille de la lettre
            $angle = mt_rand(0, 180); // Définition de l'angle de la lettre
            imagettftext($image, $taille, $angle, $x ,$y, $couleur_lettres, realpath($polices[array_rand($polices)]), $lettre_a_ajouter); // Traçage de la lettre
            $x = mt_rand(5, 295); // Changement de position de X
            $y = mt_rand(5, 55); // Changement de position de Y
            $i++; // Inscrémentation de 1
    }
    /**************************************/
    /*** Traçage et création du code ***/
    /**************************************/
    $nb_caracteres = 4; // Nombre de caractères
    $lettres = 'ABDEFGHJLMNPQRSTUVWXYZabdefghjmnpqrtuwy23456789'; // Caractères autorisés
    $lettres_melange = strlen($lettres); // Mélange des caractères
    $code = ''; // Création de $code
    $x = mt_rand(10, 20); // Définition aléatoire de X
    $y = ($hauteur / 2) + mt_rand(5, 15); // Definition de Y ~ au milieu de l'image
    $i = 0;
    // Boucle pour dessiner les lettres
    for ($i = 0; $i < $nb_caracteres; $i++)
    {
            $lettre_a_ajouter = $lettres[mt_rand(0, $lettres_melange - 1)]; // Selection de la lettres
            $taille = mt_rand(30,40); // Définition de la taille
            $angle = mt_rand(-20, 25); // Définition de l'angle
            $code .=  $lettre_a_ajouter; // Ajout de la lettre dans $code
            $couleur_lettre = imagecolorallocate($image, mt_rand(150, 255), mt_rand(150, 255), mt_rand(150, 255)); // Selection de la couleur de la lettre
            imagettftext($image, $taille, $angle, $x, $y, $couleur_lettre, realpath($polices[array_rand($polices)]), $lettre_a_ajouter); // Traçage de la lettre
            $x += $taille + mt_rand(5, 10); // Changement de position de X
            $y = ($hauteur / 2) + mt_rand(0, 20); // Petit changement de position de Y
    }
    /**************************************/
    /***  Traçage des lignes/cercles sur le devant ***/
    /**************************************/
    // 2 lignes vertial
    for($i = 0; $i < 2; $i++)
    {
            $couleur_ligne = imagecolorallocate($image, mt_rand(0, 150), mt_rand(0, 150), mt_rand(0, 150)); // Couleur de la ligne
            imageline($image, 0, mt_rand(0, $hauteur), $largeur, mt_rand(0, $hauteur), $couleur_ligne); // Traçage de la ligne
    }
    // 2 lignes horizontal
    for($i = 0; $i < 2; $i++)
    {
            $couleur_ligne = imagecolorallocate($image, mt_rand(0, 150), mt_rand(0, 150), mt_rand(0, 150)); // Couleur de la ligne
            imageline($image, mt_rand(0, $largeur), 0, mt_rand(0, $largeur), $hauteur, $couleur_ligne); // Traçage de la ligne
    }
    $_SESSION['captcha'] = $code; // Enregistrement du $code dans la session
    header('Content-type: image/png'); // Déclaration de la création d'un image PNG
    imagepng($image); // Création de l'image
    imagettftext($image, 30, 0, 40, 50, $textcolor, '../divers/fonts/arimo.ttf', $code);
    //imagedestroy($image);
?>


<!-- 
session_start();
$chaine = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
$code = '';
for ($i = 0; $i < 5; $i++) {
  $code .= $chaine[rand(0, strlen($chaine) - 1)];
}
$_SESSION['captcha'] = $code;
header('Content-type: image/png');
$largeur = 100;
$hauteur = 50;
$image = imagecreate($largeur, $hauteur);
$couleur_fond = imagecolorallocate($image, 255, 255, 255);
$couleur_texte = imagecolorallocate($image, 0, 0, 0);
imagestring($image, 5, 25, 15, $code, $couleur_texte);
imagepng($image);
imagedestroy($image); 


session_start();

// Génère un code aléatoire de 6 caractères pour le captcha
$code = substr(str_shuffle('abcdefghijklmnopqrstuvwxyz0123456789'), 0, 6);

// Stocke le code en session pour vérification ultérieure
$_SESSION['captcha'] = $code;

// Crée une image contenant le code et l'affiche
$width = 120;
$height = 40;
$image = imagecreate($width, $height);
$background = imagecolorallocate($image, 255, 255, 255);
$textcolor = imagecolorallocate($image, 0, 0, 0);
imagestring($image, 5, 30, 12, $code, $textcolor);

header('Content-type: image/png');
imagepng($image);
imagedestroy($image);


session_start();
$code = substr(str_shuffle('abcdefghjklmnpqrstuvwxyz23456789'), 0, 6);
$_SESSION['captcha'] = $code;
$width = 240;
$height = 80;
$image = imagecreate($width, $height);
$background = imagecolorallocate($image, 255, 255, 255);
$textcolor = imagecolorallocate($image, 0, 0, 0);

// Ajout de ratures à l'image
for ($i = 0; $i < 10; $i++) {
    $x1 = rand(0, $width);
    $y1 = rand(0, $height);
    $x2 = rand(0, $width);
    $y2 = rand(0, $height);
    imageline($image, $x1, $y1, $x2, $y2, $textcolor);
}


// Ajout de texte à l'image
imagettftext($image, 30, 0, 40, 50, $textcolor, '../divers/fonts/arimo.ttf', $code);
header('Content-type: image/png');
imagepng($image);
imagedestroy($image);


-->