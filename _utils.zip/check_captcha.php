<?php
session_start();

// Vérifie si la requête est de type POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	// Récupère les données envoyées par JavaScript
	$data = json_decode(file_get_contents('php://input'), true);

	// Récupère la valeur du captcha généré et l'entrée utilisateur
	$captchaValue = $_SESSION['captcha'];
	$userInput = $data['userInput'];

	// Compare les valeurs et renvoie true ou false à JavaScript
	if ($captchaValue == $userInput) {
		echo json_encode(true);
	} else {
		echo json_encode(false);
	}
}
?>
