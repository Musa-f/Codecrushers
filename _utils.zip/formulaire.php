<?php
require_once(__DIR__.'/config.php');
// Connexion à la base de données
$servername = "localhost";
$username = "u989707743_Portfolio";
$password = $pw_portfolio;
$dbname = "u989707743_messages";

try {
    $PDO = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $PDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Récupération des données du formulaire
$nom = $_POST['nom'];
$email = $_POST['email'];
$message = $_POST['message'];

// Validation des données avec les expressions régulières
$nomRegex = '/^[a-zA-ZÀ-ÿ\'\-\ ]+$/';
$mailRegex = '/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/';
$msgRegex = '/^[a-zA-ZÀ-ÿ0-9\'\-\s,.():;?!\n\r]+$/';

if (!preg_match($nomRegex, $nom)) {
    // Erreur : nom invalide
    echo json_encode(array("success" => false, "message" => "Nom invalide."));
} else if (!preg_match($mailRegex, $email)) {
    // Erreur : adresse email invalide
    echo json_encode(array("success" => false, "message" => "Adresse email invalide."));
} else if (!preg_match($msgRegex, $message)) {
    // Erreur : message invalide
    echo json_encode(array("success" => false, "message" => "Message invalide."));
} else {
    // Insertion des données dans la base de données
    $stmt = $PDO->prepare("INSERT INTO message (nom, email, message) VALUES (:nom, :email, :message)");
    $stmt->bindParam(':nom', $nom);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':message', $message);
    $stmt->execute();
    $stmt->closeCursor();

    // Envoi de la réponse JSON de succès
    echo json_encode(array("success" => true));
}

// Fermeture de la connexion à la base de données
$PDO = null;
?>
